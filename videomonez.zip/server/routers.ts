import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import * as db from "./db";

// ============================================================================
// AUTH ROUTER
// ============================================================================
const authRouter = router({
  me: publicProcedure.query((opts) => opts.ctx.user),
  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true } as const;
  }),
});

// ============================================================================
// USER ROUTER
// ============================================================================
const userRouter = router({
  getProfile: protectedProcedure.query(async ({ ctx }) => {
    const user = await db.getUserById(ctx.user.id);
    if (!user) throw new TRPCError({ code: "NOT_FOUND" });
    return user;
  }),

  updateProfile: protectedProcedure
    .input(
      z.object({
        name: z.string().optional(),
        bio: z.string().optional(),
        avatarUrl: z.string().url().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await db.updateUser(ctx.user.id, input);
    }),

  upgradeToCreator: protectedProcedure
    .input(
      z.object({
        paypalEmail: z.string().email(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "user") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "User is already a creator or admin",
        });
      }

      return await db.updateUser(ctx.user.id, {
        role: "creator",
        paypalEmail: input.paypalEmail,
      });
    }),

  getCreatorStats: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "creator" && ctx.user.role !== "admin") {
      throw new TRPCError({ code: "FORBIDDEN" });
    }

    const creatorId = ctx.user.id;
    const videos = await db.getVideosByCreator(creatorId, 1000);
    const earnings = await db.getCreatorEarnings(creatorId);
    const withdrawals = await db.getWithdrawalsByCreator(creatorId);

    const totalViews = videos.reduce((sum, v) => sum + v.views, 0);
    const publishedCount = videos.filter((v) => v.status === "published").length;

    return {
      totalViews,
      publishedVideos: publishedCount,
      totalEarnings: earnings.total,
      pendingEarnings: earnings.pending,
      withdrawals,
      videos,
    };
  }),
});

// ============================================================================
// VIDEO ROUTER
// ============================================================================
const videoRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1).max(255),
        description: z.string().optional(),
        category: z.string().min(1),
        tags: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "creator" && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      const video = await db.createVideo({
        creatorId: ctx.user.id,
        title: input.title,
        description: input.description,
        category: input.category,
        tags: input.tags ? JSON.stringify(input.tags) : null,
        status: "draft",
      });

      return video;
    }),

  publish: protectedProcedure
    .input(z.object({ videoId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const video = await db.getVideoById(input.videoId);
      if (!video) throw new TRPCError({ code: "NOT_FOUND" });

      if (video.creatorId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      // Create default ads for the video
      await db.createAd({
        videoId: input.videoId,
        type: "pre-roll",
        cpmRate: "3.50",
        cpcRate: "0.75",
      });

      await db.createAd({
        videoId: input.videoId,
        type: "mid-roll",
        positionSeconds: 30,
        cpmRate: "2.50",
        cpcRate: "0.50",
      });

      await db.createAd({
        videoId: input.videoId,
        type: "post-roll",
        cpmRate: "2.00",
        cpcRate: "0.50",
      });

      const updated = await db.updateVideo(input.videoId, {
        status: "published",
        publishedAt: new Date(),
      });

      return updated;
    }),

  delete: protectedProcedure
    .input(z.object({ videoId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const video = await db.getVideoById(input.videoId);
      if (!video) throw new TRPCError({ code: "NOT_FOUND" });

      if (video.creatorId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      return await db.updateVideo(input.videoId, { status: "deleted" });
    }),

  getById: publicProcedure
    .input(z.object({ videoId: z.number() }))
    .query(async ({ input }) => {
      const video = await db.getVideoById(input.videoId);
      if (!video) throw new TRPCError({ code: "NOT_FOUND" });
      return video;
    }),

  getFeed: publicProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(10),
        offset: z.number().min(0).default(0),
        category: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      return await db.getPublishedVideos(input.limit, input.offset, input.category);
    }),

  getMyVideos: protectedProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(10),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      if (ctx.user.role !== "creator" && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      return await db.getVideosByCreator(ctx.user.id, input.limit, input.offset);
    }),

  recordView: publicProcedure
    .input(z.object({ videoId: z.number(), watchDuration: z.number().default(0) }))
    .mutation(async ({ input }) => {
      await db.incrementVideoViews(input.videoId);

      // Record analytics
      await db.createVideoAnalytic({
        videoId: input.videoId,
        watchDuration: input.watchDuration,
        completed: input.watchDuration > 0,
      });

      // Simulate earnings from view (CPM based)
      const video = await db.getVideoById(input.videoId);
      if (video) {
        const ads = await db.getAdsByVideo(input.videoId);
        for (const ad of ads) {
          if (Math.random() < 0.1) {
            // 10% chance of impression
            const cpmAmount = (typeof ad.cpmRate === 'string' ? parseFloat(ad.cpmRate) : ad.cpmRate) / 1000;
            await db.createEarning({
              creatorId: video.creatorId,
              videoId: input.videoId,
              adId: ad.id,
              amount: cpmAmount.toFixed(4),
              type: "view",
            });

            await db.updateAd(ad.id, {
              impressions: ad.impressions + 1,
            });
          }
        }
      }

      return { success: true };
    }),
});

// ============================================================================
// COMMENTS ROUTER
// ============================================================================
const commentsRouter = router({
  add: protectedProcedure
    .input(
      z.object({
        videoId: z.number(),
        content: z.string().min(1).max(1000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const video = await db.getVideoById(input.videoId);
      if (!video) throw new TRPCError({ code: "NOT_FOUND" });

      const comment = await db.createComment({
        videoId: input.videoId,
        userId: ctx.user.id,
        content: input.content,
      });

      // Notify creator
      await db.createNotification({
        userId: video.creatorId,
        type: "new_comment",
        title: "Nuevo comentario",
        message: `${ctx.user.name} comentó en tu video "${video.title}"`,
      });

      return comment;
    }),

  getByVideo: publicProcedure
    .input(
      z.object({
        videoId: z.number(),
        limit: z.number().min(1).max(50).default(20),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ input }) => {
      return await db.getCommentsByVideo(input.videoId, input.limit, input.offset);
    }),

  delete: protectedProcedure
    .input(z.object({ commentId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // TODO: Verify ownership
      await db.deleteComment(input.commentId);
      return { success: true };
    }),
});

// ============================================================================
// REACTIONS ROUTER
// ============================================================================
const reactionsRouter = router({
  toggle: protectedProcedure
    .input(
      z.object({
        videoId: z.number(),
        type: z.enum(["like", "dislike"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await db.toggleReaction(input.videoId, ctx.user.id, input.type);
      const reactions = await db.getReactionsByVideo(input.videoId);
      return reactions;
    }),

  getByVideo: publicProcedure
    .input(z.object({ videoId: z.number() }))
    .query(async ({ input }) => {
      return await db.getReactionsByVideo(input.videoId);
    }),
});

// ============================================================================
// EARNINGS ROUTER
// ============================================================================
const earningsRouter = router({
  getStats: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "creator" && ctx.user.role !== "admin") {
      throw new TRPCError({ code: "FORBIDDEN" });
    }

    return await db.getCreatorEarnings(ctx.user.id);
  }),

  getByVideo: protectedProcedure
    .input(z.object({ videoId: z.number() }))
    .query(async ({ ctx, input }) => {
      const video = await db.getVideoById(input.videoId);
      if (!video) throw new TRPCError({ code: "NOT_FOUND" });

      if (video.creatorId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      // TODO: Get earnings for specific video
      return [];
    }),
});

// ============================================================================
// WITHDRAWAL ROUTER
// ============================================================================
const withdrawalRouter = router({
  request: protectedProcedure
    .input(
      z.object({
        amount: z.number().min(5),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "creator") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      const user = await db.getUserById(ctx.user.id);
      if (!user?.paypalEmail) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "PayPal email not set",
        });
      }

      const earnings = await db.getCreatorEarnings(ctx.user.id);
      if (earnings.pending < input.amount) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Insufficient pending earnings",
        });
      }

      const withdrawal = await db.createWithdrawal({
        creatorId: ctx.user.id,
        amount: input.amount.toFixed(2),
        paypalEmail: user.paypalEmail,
        status: "pending",
      });

      return withdrawal;
    }),

  getHistory: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "creator") {
      throw new TRPCError({ code: "FORBIDDEN" });
    }

    return await db.getWithdrawalsByCreator(ctx.user.id);
  }),
});

// ============================================================================
// ADMIN ROUTER
// ============================================================================
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
  return next({ ctx });
});

const adminRouter = router({
  getPendingWithdrawals: adminProcedure.query(async () => {
    return await db.getPendingWithdrawals();
  }),

  approveWithdrawal: adminProcedure
    .input(z.object({ withdrawalId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const withdrawal = await db.updateWithdrawal(input.withdrawalId, {
        status: "completed",
        processedAt: new Date(),
        reviewedBy: ctx.user.id,
      });

      if (withdrawal) {
        // Notify creator
        await db.createNotification({
          userId: withdrawal.creatorId,
          type: "withdrawal_approved",
          title: "Retiro aprobado",
          message: `Tu retiro de $${withdrawal.amount} ha sido aprobado`,
        });
      }

      return withdrawal;
    }),

  rejectWithdrawal: adminProcedure
    .input(
      z.object({
        withdrawalId: z.number(),
        reason: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const withdrawal = await db.updateWithdrawal(input.withdrawalId, {
        status: "rejected",
        processedAt: new Date(),
        reviewedBy: ctx.user.id,
        reason: input.reason,
      });

      if (withdrawal) {
        // Notify creator
        await db.createNotification({
          userId: withdrawal.creatorId,
          type: "withdrawal_rejected",
          title: "Retiro rechazado",
          message: `Tu retiro ha sido rechazado. Razón: ${input.reason}`,
        });
      }

      return withdrawal;
    }),

  getPendingFlags: adminProcedure.query(async () => {
    return await db.getPendingFlags();
  }),

  reviewFlag: adminProcedure
    .input(
      z.object({
        flagId: z.number(),
        action: z.enum(["approve", "reject"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const flag = await db.updateContentFlag(input.flagId, {
        status: input.action === "approve" ? "resolved" : "reviewed",
        reviewedBy: ctx.user.id,
        reviewedAt: new Date(),
      });

      if (input.action === "approve" && flag?.videoId) {
        // Delete the video
        await db.updateVideo(flag.videoId, { status: "deleted" });
      }

      return flag;
    }),
});

// ============================================================================
// MODERATION ROUTER
// ============================================================================
const moderationRouter = router({
  reportContent: protectedProcedure
    .input(
      z.object({
        videoId: z.number().optional(),
        commentId: z.number().optional(),
        reason: z.enum(["spam", "inappropriate", "copyright", "harassment", "other"]),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (!input.videoId && !input.commentId) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Either videoId or commentId is required",
        });
      }

      return await db.createContentFlag({
        videoId: input.videoId,
        commentId: input.commentId,
        reportedBy: ctx.user.id,
        reason: input.reason,
        description: input.description,
        status: "pending",
      });
    }),
});

// ============================================================================
// NOTIFICATIONS ROUTER
// ============================================================================
const notificationsRouter = router({
  getAll: protectedProcedure.query(async ({ ctx }) => {
    return await db.getNotificationsByUser(ctx.user.id);
  }),

  markAsRead: protectedProcedure
    .input(z.object({ notificationId: z.number() }))
    .mutation(async ({ input }) => {
      await db.markNotificationAsRead(input.notificationId);
      return { success: true };
    }),
});

// ============================================================================
// MAIN ROUTER
// ============================================================================
export const appRouter = router({
  system: systemRouter,
  auth: authRouter,
  user: userRouter,
  video: videoRouter,
  comments: commentsRouter,
  reactions: reactionsRouter,
  earnings: earningsRouter,
  withdrawal: withdrawalRouter,
  admin: adminRouter,
  moderation: moderationRouter,
  notifications: notificationsRouter,
});

export type AppRouter = typeof appRouter;
