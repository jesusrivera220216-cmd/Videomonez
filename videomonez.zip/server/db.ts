import { eq, and, desc, asc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  videos,
  InsertVideo,
  comments,
  InsertComment,
  reactions,
  InsertReaction,
  earnings,
  InsertEarning,
  withdrawals,
  InsertWithdrawal,
  contentFlags,
  InsertContentFlag,
  notifications,
  InsertNotification,
  ads,
  InsertAd,
  adImpressions,
  InsertAdImpression,
  videoAnalytics,
  InsertVideoAnalytic,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUser(id: number, data: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(users).set(data).where(eq(users.id, id));
  return getUserById(id);
}

// Video queries
export async function createVideo(data: InsertVideo) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(videos).values(data);
  return result[0];
}

export async function getVideoById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getVideosByCreator(creatorId: number, limit = 10, offset = 0) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(videos)
    .where(eq(videos.creatorId, creatorId))
    .orderBy(desc(videos.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function getPublishedVideos(limit = 10, offset = 0, category?: string) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [eq(videos.status, "published")];
  if (category) {
    conditions.push(eq(videos.category, category));
  }

  return await db
    .select()
    .from(videos)
    .where(and(...conditions))
    .orderBy(desc(videos.publishedAt))
    .limit(limit)
    .offset(offset);
}

export async function updateVideo(id: number, data: Partial<InsertVideo>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(videos).set(data).where(eq(videos.id, id));
  return getVideoById(id);
}

export async function incrementVideoViews(id: number) {
  const db = await getDb();
  if (!db) return;

  await db
    .update(videos)
    .set({ views: sql`views + 1` })
    .where(eq(videos.id, id));
}

// Comment queries
export async function createComment(data: InsertComment) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(comments).values(data);
  return result[0];
}

export async function getCommentsByVideo(videoId: number, limit = 20, offset = 0) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(comments)
    .where(eq(comments.videoId, videoId))
    .orderBy(desc(comments.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function deleteComment(id: number) {
  const db = await getDb();
  if (!db) return;

  await db.delete(comments).where(eq(comments.id, id));
}

// Reaction queries
export async function toggleReaction(videoId: number, userId: number, type: "like" | "dislike") {
  const db = await getDb();
  if (!db) return;

  const existing = await db
    .select()
    .from(reactions)
    .where(and(eq(reactions.videoId, videoId), eq(reactions.userId, userId)))
    .limit(1);

  if (existing.length > 0) {
    await db
      .delete(reactions)
      .where(
        and(
          eq(reactions.videoId, videoId),
          eq(reactions.userId, userId),
          eq(reactions.type, type)
        )
      );
  } else {
    await db.insert(reactions).values({ videoId, userId, type });
  }
}

export async function getReactionsByVideo(videoId: number) {
  const db = await getDb();
  if (!db) return { likes: 0, dislikes: 0 };

  const result = await db
    .select({
      type: reactions.type,
      count: sql<number>`COUNT(*) as count`,
    })
    .from(reactions)
    .where(eq(reactions.videoId, videoId))
    .groupBy(reactions.type);

  const likes = result.find((r) => r.type === "like")?.count || 0;
  const dislikes = result.find((r) => r.type === "dislike")?.count || 0;

  return { likes, dislikes };
}

// Earnings queries
export async function createEarning(data: InsertEarning) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(earnings).values(data);
  return result[0];
}

export async function getCreatorEarnings(creatorId: number) {
  const db = await getDb();
  if (!db) return { total: 0, pending: 0, videos: [] };

  const earningRecords = await db
    .select()
    .from(earnings)
    .where(eq(earnings.creatorId, creatorId));

  const total = earningRecords.reduce((sum, e) => sum + parseFloat(e.amount.toString()), 0);

  const withdrawalRecords = await db
    .select()
    .from(withdrawals)
    .where(
      and(
        eq(withdrawals.creatorId, creatorId),
        eq(withdrawals.status, "completed")
      )
    );

  const withdrawn = withdrawalRecords.reduce(
    (sum, w) => sum + parseFloat(w.amount.toString()),
    0
  );
  const pending = total - withdrawn;

  return { total, pending, videos: earningRecords };
}

// Withdrawal queries
export async function createWithdrawal(data: InsertWithdrawal) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(withdrawals).values(data);
  return result[0];
}

export async function getWithdrawalsByCreator(creatorId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(withdrawals)
    .where(eq(withdrawals.creatorId, creatorId))
    .orderBy(desc(withdrawals.requestedAt));
}

export async function getPendingWithdrawals() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(withdrawals)
    .where(eq(withdrawals.status, "pending"))
    .orderBy(asc(withdrawals.requestedAt));
}

export async function updateWithdrawal(id: number, data: Partial<InsertWithdrawal>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(withdrawals).set(data).where(eq(withdrawals.id, id));
  const result = await db.select().from(withdrawals).where(eq(withdrawals.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Content flags queries
export async function createContentFlag(data: InsertContentFlag) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(contentFlags).values(data);
  return result[0];
}

export async function getPendingFlags() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(contentFlags)
    .where(eq(contentFlags.status, "pending"))
    .orderBy(asc(contentFlags.createdAt));
}

export async function updateContentFlag(id: number, data: Partial<InsertContentFlag>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(contentFlags).set(data).where(eq(contentFlags.id, id));
  const result = await db
    .select()
    .from(contentFlags)
    .where(eq(contentFlags.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Notification queries
export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(notifications).values(data);
  return result[0];
}

export async function getNotificationsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function markNotificationAsRead(id: number) {
  const db = await getDb();
  if (!db) return;

  await db.update(notifications).set({ read: true }).where(eq(notifications.id, id));
}

// Ads queries
export async function createAd(data: InsertAd) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(ads).values(data);
  return result[0];
}

export async function getAdsByVideo(videoId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(ads).where(eq(ads.videoId, videoId));
}

export async function updateAd(id: number, data: Partial<InsertAd>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(ads).set(data).where(eq(ads.id, id));
  const result = await db.select().from(ads).where(eq(ads.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Ad impressions queries
export async function createAdImpression(data: InsertAdImpression) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(adImpressions).values(data);
  return result[0];
}

// Video analytics queries
export async function createVideoAnalytic(data: InsertVideoAnalytic) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(videoAnalytics).values(data);
  return result[0];
}

export async function getVideoAnalytics(videoId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(videoAnalytics).where(eq(videoAnalytics.videoId, videoId));
}
