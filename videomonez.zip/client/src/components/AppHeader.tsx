import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Play, LogOut } from "lucide-react";
import { getLoginUrl } from "@/const";
import NotificationCenter from "./NotificationCenter";

export default function AppHeader() {
  const { user, logout } = useAuth();

  return (
    <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur sticky top-0 z-10">
      <div className="container py-4 flex items-center justify-between">
        <Link href="/">
          <a className="flex items-center gap-2 hover:opacity-80 transition">
            <Play className="w-6 h-6 text-red-500" />
            <span className="text-xl font-bold text-white">VideoMonez</span>
          </a>
        </Link>

        <div className="flex items-center gap-6">
          {/* Navigation */}
          <nav className="hidden sm:flex items-center gap-6">
            <Link href="/feed">
              <a className="text-slate-300 hover:text-white transition">Feed</a>
            </Link>
            {user?.role === "creator" || user?.role === "admin" ? (
              <>
                <Link href="/creator/dashboard">
                  <a className="text-slate-300 hover:text-white transition">
                    Dashboard
                  </a>
                </Link>
                <Link href="/creator/upload">
                  <a className="text-slate-300 hover:text-white transition">
                    Subir
                  </a>
                </Link>
              </>
            ) : null}
            {user?.role === "admin" ? (
              <Link href="/admin">
                <a className="text-slate-300 hover:text-white transition">
                  Admin
                </a>
              </Link>
            ) : null}
          </nav>

          {/* Auth Section */}
          <div className="flex items-center gap-4">
            {user ? (
              <>
                <NotificationCenter />
                <Link href="/profile">
                  <a className="text-slate-300 hover:text-white transition">
                    Perfil
                  </a>
                </Link>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={logout}
                  className="gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Salir
                </Button>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button size="sm" className="bg-red-600 hover:bg-red-700">
                  Iniciar Sesión
                </Button>
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
