import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";

interface CommentItemProps {
  id: number;
  content: string;
  userId: number;
  createdAt: Date;
  currentUserId?: number;
  onDelete?: (id: number) => Promise<void>;
  isDeleting?: boolean;
}

export default function CommentItem({
  id,
  content,
  userId,
  createdAt,
  currentUserId,
  onDelete,
  isDeleting,
}: CommentItemProps) {
  const isOwnComment = currentUserId === userId;

  const handleDelete = async () => {
    if (!onDelete) return;

    try {
      await onDelete(id);
      toast.success("Comentario eliminado");
    } catch (error) {
      toast.error("Error al eliminar comentario");
    }
  };

  return (
    <div className="bg-slate-800 rounded-lg p-4 space-y-2 border border-slate-700">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-slate-300 text-sm">{content}</p>
          <p className="text-xs text-slate-500 mt-2">
            Usuario #{userId} •{" "}
            {createdAt.toLocaleDateString()}
          </p>
        </div>

        {isOwnComment && onDelete && (
          <Button
            size="sm"
            variant="ghost"
            onClick={handleDelete}
            disabled={isDeleting}
            className="ml-2"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
          </Button>
        )}
      </div>
    </div>
  );
}
