import { Link } from "wouter";
import { Play, Eye, ThumbsUp, ThumbsDown } from "lucide-react";

interface VideoCardProps {
  id: number;
  title: string;
  description?: string;
  category: string;
  views: number;
  likes: number;
  dislikes: number;
  thumbnailUrl?: string;
  status?: "draft" | "published" | "deleted";
}

export default function VideoCard({
  id,
  title,
  description,
  category,
  views,
  likes,
  dislikes,
  thumbnailUrl,
  status,
}: VideoCardProps) {
  return (
    <Link href={`/video/${id}`}>
      <a className="group cursor-pointer block">
        <div className="bg-slate-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-red-500 transition">
          {/* Thumbnail */}
          <div className="relative bg-slate-700 aspect-video flex items-center justify-center group-hover:bg-slate-600 transition">
            {thumbnailUrl ? (
              <img
                src={thumbnailUrl}
                alt={title}
                className="w-full h-full object-cover"
              />
            ) : (
              <Play className="w-12 h-12 text-slate-500" />
            )}
            <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition flex items-center justify-center opacity-0 group-hover:opacity-100">
              <Play className="w-12 h-12 text-white" />
            </div>
          </div>

          {/* Info */}
          <div className="p-3 space-y-2">
            <h3 className="font-semibold text-white line-clamp-2 group-hover:text-red-400 transition">
              {title}
            </h3>
            <p className="text-sm text-slate-400 line-clamp-2">
              {description || "Sin descripción"}
            </p>

            {/* Stats */}
            <div className="flex items-center gap-4 text-xs text-slate-400 pt-2">
              <div className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                <span>{views.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-1">
                <ThumbsUp className="w-4 h-4" />
                <span>{likes.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-1">
                <ThumbsDown className="w-4 h-4" />
                <span>{dislikes.toLocaleString()}</span>
              </div>
            </div>

            {/* Category & Status */}
            <div className="flex items-center justify-between pt-2">
              <span className="inline-block bg-red-600/20 text-red-400 text-xs px-2 py-1 rounded">
                {category}
              </span>
              {status && (
                <span
                  className={`text-xs px-2 py-1 rounded ${
                    status === "published"
                      ? "bg-green-600/20 text-green-400"
                      : status === "draft"
                      ? "bg-yellow-600/20 text-yellow-400"
                      : "bg-red-600/20 text-red-400"
                  }`}
                >
                  {status === "published"
                    ? "Publicado"
                    : status === "draft"
                    ? "Borrador"
                    : "Eliminado"}
                </span>
              )}
            </div>
          </div>
        </div>
      </a>
    </Link>
  );
}
