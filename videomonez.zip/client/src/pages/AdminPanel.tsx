import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Play, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";

export default function AdminPanel() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<"withdrawals" | "flags">("withdrawals");
  const [rejectionReason, setRejectionReason] = useState("");
  const [selectedWithdrawalId, setSelectedWithdrawalId] = useState<number | null>(null);

  const { data: pendingWithdrawals, isLoading: withdrawalsLoading } =
    trpc.admin.getPendingWithdrawals.useQuery();

  const { data: pendingFlags, isLoading: flagsLoading } = trpc.admin.getPendingFlags.useQuery();

  const approveWithdrawalMutation = trpc.admin.approveWithdrawal.useMutation();
  const rejectWithdrawalMutation = trpc.admin.rejectWithdrawal.useMutation();
  const reviewFlagMutation = trpc.admin.reviewFlag.useMutation();

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-400 text-lg mb-4">Acceso denegado</p>
          <Link href="/">
            <a>
              <Button>Volver al inicio</Button>
            </a>
          </Link>
        </div>
      </div>
    );
  }

  const handleApproveWithdrawal = async (withdrawalId: number) => {
    try {
      await approveWithdrawalMutation.mutateAsync({ withdrawalId });
      toast.success("Retiro aprobado");
    } catch (error) {
      toast.error("Error al aprobar retiro");
    }
  };

  const handleRejectWithdrawal = async (withdrawalId: number) => {
    if (!rejectionReason.trim()) {
      toast.error("Ingresa una razón para rechazar");
      return;
    }

    try {
      await rejectWithdrawalMutation.mutateAsync({
        withdrawalId,
        reason: rejectionReason,
      });
      setRejectionReason("");
      setSelectedWithdrawalId(null);
      toast.success("Retiro rechazado");
    } catch (error) {
      toast.error("Error al rechazar retiro");
    }
  };

  const handleApproveFlag = async (flagId: number) => {
    try {
      await reviewFlagMutation.mutateAsync({
        flagId,
        action: "approve",
      });
      toast.success("Contenido eliminado");
    } catch (error) {
      toast.error("Error al procesar reporte");
    }
  };

  const handleRejectFlag = async (flagId: number) => {
    try {
      await reviewFlagMutation.mutateAsync({
        flagId,
        action: "reject",
      });
      toast.success("Reporte rechazado");
    } catch (error) {
      toast.error("Error al procesar reporte");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition">
              <Play className="w-6 h-6 text-red-500" />
              <span className="text-xl font-bold text-white">VideoMonez</span>
            </a>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/feed">
              <a className="text-slate-300 hover:text-white transition">Feed</a>
            </Link>
            <Link href="/profile">
              <a className="text-slate-300 hover:text-white transition">Perfil</a>
            </Link>
          </div>
        </div>
      </div>

      <div className="container py-8">
        <div className="space-y-8">
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold text-white">Panel de Administración</h1>
            <p className="text-slate-400">Gestiona retiros y contenido reportado</p>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 border-b border-slate-700">
            <button
              onClick={() => setActiveTab("withdrawals")}
              className={`px-4 py-2 font-semibold transition ${
                activeTab === "withdrawals"
                  ? "text-red-500 border-b-2 border-red-500"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Retiros Pendientes ({pendingWithdrawals?.length || 0})
            </button>
            <button
              onClick={() => setActiveTab("flags")}
              className={`px-4 py-2 font-semibold transition ${
                activeTab === "flags"
                  ? "text-red-500 border-b-2 border-red-500"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Contenido Reportado ({pendingFlags?.length || 0})
            </button>
          </div>

          {/* Withdrawals Tab */}
          {activeTab === "withdrawals" && (
            <div className="space-y-6">
              {withdrawalsLoading ? (
                <div className="flex items-center justify-center py-20">
                  <Loader2 className="w-8 h-8 animate-spin text-red-500" />
                </div>
              ) : pendingWithdrawals && pendingWithdrawals.length > 0 ? (
                <div className="space-y-4">
                  {pendingWithdrawals.map((withdrawal) => (
                    <div
                      key={withdrawal.id}
                      className="bg-slate-800 rounded-lg p-6 border border-slate-700 space-y-4"
                    >
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-slate-400 text-sm">Monto</p>
                          <p className="text-2xl font-bold text-white">
                            ${withdrawal.amount}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-sm">Email de PayPal</p>
                          <p className="text-white">{withdrawal.paypalEmail}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-sm">Solicitado</p>
                          <p className="text-white">
                            {new Date(withdrawal.requestedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-sm">ID de Creador</p>
                          <p className="text-white">#{withdrawal.creatorId}</p>
                        </div>
                      </div>

                      {selectedWithdrawalId === withdrawal.id ? (
                        <div className="bg-slate-700 rounded p-4 space-y-3">
                          <Textarea
                            placeholder="Razón del rechazo..."
                            value={rejectionReason}
                            onChange={(e) => setRejectionReason(e.target.value)}
                            className="bg-slate-600 border-slate-500 text-white placeholder:text-slate-400 resize-none"
                            rows={3}
                          />
                          <div className="flex gap-2">
                            <Button
                              onClick={() => setSelectedWithdrawalId(null)}
                              variant="outline"
                              className="flex-1"
                            >
                              Cancelar
                            </Button>
                            <Button
                              onClick={() =>
                                handleRejectWithdrawal(withdrawal.id)
                              }
                              disabled={rejectWithdrawalMutation.isPending}
                              className="flex-1 bg-red-600 hover:bg-red-700"
                            >
                              Confirmar Rechazo
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex gap-2">
                          <Button
                            onClick={() =>
                              handleApproveWithdrawal(withdrawal.id)
                            }
                            disabled={approveWithdrawalMutation.isPending}
                            className="flex-1 bg-green-600 hover:bg-green-700 gap-2"
                          >
                            <CheckCircle className="w-4 h-4" />
                            Aprobar
                          </Button>
                          <Button
                            onClick={() =>
                              setSelectedWithdrawalId(withdrawal.id)
                            }
                            variant="outline"
                            className="flex-1 gap-2"
                          >
                            <XCircle className="w-4 h-4" />
                            Rechazar
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-400 text-center py-12">
                  No hay retiros pendientes
                </p>
              )}
            </div>
          )}

          {/* Flags Tab */}
          {activeTab === "flags" && (
            <div className="space-y-6">
              {flagsLoading ? (
                <div className="flex items-center justify-center py-20">
                  <Loader2 className="w-8 h-8 animate-spin text-red-500" />
                </div>
              ) : pendingFlags && pendingFlags.length > 0 ? (
                <div className="space-y-4">
                  {pendingFlags.map((flag) => (
                    <div
                      key={flag.id}
                      className="bg-slate-800 rounded-lg p-6 border border-slate-700 space-y-4"
                    >
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-slate-400 text-sm">Razón</p>
                          <p className="text-white capitalize">{flag.reason}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-sm">Tipo</p>
                          <p className="text-white">
                            {flag.videoId ? "Video" : "Comentario"}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-sm">Reportado por</p>
                          <p className="text-white">Usuario #{flag.reportedBy}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-sm">Fecha</p>
                          <p className="text-white">
                            {new Date(flag.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>

                      {flag.description && (
                        <div>
                          <p className="text-slate-400 text-sm mb-2">Descripción</p>
                          <p className="text-white bg-slate-700 rounded p-3">
                            {flag.description}
                          </p>
                        </div>
                      )}

                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleApproveFlag(flag.id)}
                          disabled={reviewFlagMutation.isPending}
                          className="flex-1 bg-red-600 hover:bg-red-700 gap-2"
                        >
                          <CheckCircle className="w-4 h-4" />
                          Eliminar Contenido
                        </Button>
                        <Button
                          onClick={() => handleRejectFlag(flag.id)}
                          disabled={reviewFlagMutation.isPending}
                          variant="outline"
                          className="flex-1 gap-2"
                        >
                          <XCircle className="w-4 h-4" />
                          Rechazar Reporte
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-400 text-center py-12">
                  No hay reportes pendientes
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
