import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Loader2, Play } from "lucide-react";
import { toast } from "sonner";

export default function CreatorSetup() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [paypalEmail, setPaypalEmail] = useState("");
  const [agreed, setAgreed] = useState(false);

  const upgradeToCreatorMutation = trpc.user.upgradeToCreator.useMutation();

  if (user?.role === "creator" || user?.role === "admin") {
    navigate("/creator/dashboard");
    return null;
  }

  const handleUpgrade = async () => {
    if (!paypalEmail.trim()) {
      toast.error("Por favor ingresa tu email de PayPal");
      return;
    }

    if (!agreed) {
      toast.error("Debes aceptar los términos y condiciones");
      return;
    }

    try {
      await upgradeToCreatorMutation.mutateAsync({ paypalEmail });
      toast.success("¡Felicidades! Ahora eres un creador");
      navigate("/creator/dashboard");
    } catch (error) {
      toast.error("Error al actualizar a creador");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur">
        <div className="container py-4 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2 hover:opacity-80 transition">
            <Play className="w-6 h-6 text-red-500" />
            <span className="text-xl font-bold text-white">VideoMonez</span>
          </a>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12 flex items-center justify-center">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold text-white">Conviértete en Creador</h1>
            <p className="text-slate-400">
              Comienza a monetizar tus videos y gana dinero
            </p>
          </div>

          <div className="bg-slate-800 rounded-lg p-8 space-y-6 border border-slate-700">
            {/* Benefits */}
            <div className="space-y-3">
              <h2 className="font-semibold text-white">Beneficios de ser creador:</h2>
              <ul className="space-y-2 text-slate-300 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  Monetización automática de videos
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  Dashboard con estadísticas en tiempo real
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  Retiros mensuales a PayPal
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  Acceso a herramientas de análisis
                </li>
              </ul>
            </div>

            {/* Form */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="paypal" className="text-white mb-2 block">
                  Email de PayPal
                </Label>
                <Input
                  id="paypal"
                  type="email"
                  placeholder="tu@email.com"
                  value={paypalEmail}
                  onChange={(e) => setPaypalEmail(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                />
                <p className="text-xs text-slate-400 mt-2">
                  Este email se usará para recibir tus pagos
                </p>
              </div>

              {/* Terms */}
              <div className="flex items-start gap-3">
                <Checkbox
                  id="terms"
                  checked={agreed}
                  onCheckedChange={(checked) => setAgreed(checked as boolean)}
                  className="mt-1"
                />
                <Label htmlFor="terms" className="text-sm text-slate-300 cursor-pointer">
                  Acepto los términos y condiciones de VideoMonez y confirmo que tengo 18 años o más
                </Label>
              </div>

              {/* Submit */}
              <Button
                onClick={handleUpgrade}
                disabled={upgradeToCreatorMutation.isPending}
                className="w-full bg-red-600 hover:bg-red-700"
              >
                {upgradeToCreatorMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Procesando...
                  </>
                ) : (
                  "Convertirse en Creador"
                )}
              </Button>
            </div>
          </div>

          {/* Info Box */}
          <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-4">
            <p className="text-sm text-blue-300">
              <strong>Nota:</strong> Una vez que te conviertas en creador, podrás subir videos y comenzar a ganar dinero inmediatamente.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
