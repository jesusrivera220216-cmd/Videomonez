import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Play, LogOut } from "lucide-react";
import { toast } from "sonner";

export default function Profile() {
  const { user, logout } = useAuth();
  const [name, setName] = useState(user?.name || "");
  const [bio, setBio] = useState(user?.bio || "");

  const { data: profile, isLoading } = trpc.user.getProfile.useQuery();
  const updateProfileMutation = trpc.user.updateProfile.useMutation();
  const logoutMutation = trpc.auth.logout.useMutation();

  const handleUpdateProfile = async () => {
    try {
      await updateProfileMutation.mutateAsync({
        name: name || undefined,
        bio: bio || undefined,
      });
      toast.success("Perfil actualizado");
    } catch (error) {
      toast.error("Error al actualizar perfil");
    }
  };

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      logout();
      toast.success("Sesión cerrada");
    } catch (error) {
      toast.error("Error al cerrar sesión");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition">
              <Play className="w-6 h-6 text-red-500" />
              <span className="text-xl font-bold text-white">VideoMonez</span>
            </a>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/feed">
              <a className="text-slate-300 hover:text-white transition">Feed</a>
            </Link>
            <Link href="/creator/dashboard">
              <a className="text-slate-300 hover:text-white transition">Dashboard</a>
            </Link>
          </div>
        </div>
      </div>

      <div className="container py-12">
        <div className="max-w-2xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold text-white">Mi Perfil</h1>
            <p className="text-slate-400">Administra tu información personal</p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-red-500" />
            </div>
          ) : profile ? (
            <div className="bg-slate-800 rounded-lg p-8 space-y-6 border border-slate-700">
              {/* Account Info */}
              <div className="space-y-4">
                <h2 className="text-xl font-bold text-white">Información de Cuenta</h2>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-slate-400">Email</p>
                    <p className="text-white font-semibold">{profile.email}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Rol</p>
                    <p className="text-white font-semibold capitalize">{profile.role}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Miembro desde</p>
                    <p className="text-white font-semibold">
                      {new Date(profile.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-400">Último acceso</p>
                    <p className="text-white font-semibold">
                      {new Date(profile.lastSignedIn).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>

              {/* Editable Profile */}
              <div className="space-y-4 border-t border-slate-700 pt-6">
                <h2 className="text-xl font-bold text-white">Editar Perfil</h2>

                <div>
                  <label className="text-white mb-2 block text-sm">Nombre</label>
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                  />
                </div>

                <div>
                  <label className="text-white mb-2 block text-sm">Biografía</label>
                  <Textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 resize-none"
                    rows={4}
                    placeholder="Cuéntanos sobre ti..."
                  />
                </div>

                <Button
                  onClick={handleUpdateProfile}
                  disabled={updateProfileMutation.isPending}
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  {updateProfileMutation.isPending ? "Guardando..." : "Guardar Cambios"}
                </Button>
              </div>

              {/* Creator Info */}
              {profile.role === "creator" && (
                <div className="space-y-4 border-t border-slate-700 pt-6">
                  <h2 className="text-xl font-bold text-white">Información de Creador</h2>

                  <div>
                    <p className="text-slate-400 text-sm">Email de PayPal</p>
                    <p className="text-white font-semibold">{profile.paypalEmail}</p>
                  </div>
                </div>
              )}

              {/* Logout */}
              <div className="border-t border-slate-700 pt-6">
                <Button
                  onClick={handleLogout}
                  disabled={logoutMutation.isPending}
                  variant="outline"
                  className="w-full gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  {logoutMutation.isPending ? "Cerrando sesión..." : "Cerrar Sesión"}
                </Button>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
