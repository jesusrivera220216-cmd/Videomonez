import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Play, ThumbsUp, ThumbsDown, MessageCircle, Flag } from "lucide-react";
import { toast } from "sonner";

export default function VideoPlayer() {
  const [, params] = useRoute("/video/:id");
  const videoId = params?.id ? parseInt(params.id) : 0;

  const { user, isAuthenticated } = useAuth();
  const [commentText, setCommentText] = useState("");

  // Queries
  const { data: video, isLoading: videoLoading } = trpc.video.getById.useQuery({
    videoId,
  });

  const { data: comments, isLoading: commentsLoading } = trpc.comments.getByVideo.useQuery({
    videoId,
    limit: 50,
  });

  const { data: reactions } = trpc.reactions.getByVideo.useQuery({ videoId });

  // Mutations
  const recordViewMutation = trpc.video.recordView.useMutation();
  const addCommentMutation = trpc.comments.add.useMutation();
  const toggleReactionMutation = trpc.reactions.toggle.useMutation();
  const reportContentMutation = trpc.moderation.reportContent.useMutation();

  // Effects
  useEffect(() => {
    if (videoId && !videoLoading) {
      recordViewMutation.mutate({ videoId, watchDuration: 0 });
    }
  }, [videoId, videoLoading]);

  if (videoLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-red-500" />
      </div>
    );
  }

  if (!video) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-400 text-lg mb-4">Video no encontrado</p>
          <Link href="/feed">
            <a>
              <Button>Volver al Feed</Button>
            </a>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddComment = async () => {
    if (!isAuthenticated) {
      toast.error("Debes iniciar sesión para comentar");
      return;
    }

    if (!commentText.trim()) {
      toast.error("El comentario no puede estar vacío");
      return;
    }

    try {
      await addCommentMutation.mutateAsync({
        videoId,
        content: commentText,
      });
      setCommentText("");
      toast.success("Comentario agregado");
    } catch (error) {
      toast.error("Error al agregar comentario");
    }
  };

  const handleToggleLike = async () => {
    if (!isAuthenticated) {
      toast.error("Debes iniciar sesión");
      return;
    }

    try {
      await toggleReactionMutation.mutateAsync({
        videoId,
        type: "like",
      });
    } catch (error) {
      toast.error("Error al procesar reacción");
    }
  };

  const handleToggleDislike = async () => {
    if (!isAuthenticated) {
      toast.error("Debes iniciar sesión");
      return;
    }

    try {
      await toggleReactionMutation.mutateAsync({
        videoId,
        type: "dislike",
      });
    } catch (error) {
      toast.error("Error al procesar reacción");
    }
  };

  const handleReport = async () => {
    try {
      await reportContentMutation.mutateAsync({
        videoId,
        reason: "inappropriate",
        description: "Contenido inapropiado",
      });
      toast.success("Contenido reportado");
    } catch (error) {
      toast.error("Error al reportar contenido");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition">
              <Play className="w-6 h-6 text-red-500" />
              <span className="text-xl font-bold text-white">VideoMonez</span>
            </a>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/feed">
              <a className="text-slate-300 hover:text-white transition">Feed</a>
            </Link>
            <Link href="/creator/dashboard">
              <a className="text-slate-300 hover:text-white transition">Dashboard</a>
            </Link>
            <Link href="/profile">
              <a className="text-slate-300 hover:text-white transition">Perfil</a>
            </Link>
          </div>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Video Player */}
          <div className="lg:col-span-2 space-y-6">
            {/* Video Container */}
            <div className="bg-slate-800 rounded-lg overflow-hidden aspect-video flex items-center justify-center">
              {video.videoUrl ? (
                <video
                  src={video.videoUrl}
                  controls
                  className="w-full h-full"
                />
              ) : (
                <div className="flex flex-col items-center gap-4">
                  <Play className="w-16 h-16 text-slate-600" />
                  <p className="text-slate-400">Video no disponible</p>
                </div>
              )}
            </div>

            {/* Video Info */}
            <div className="space-y-4">
              <h1 className="text-3xl font-bold text-white">{video.title}</h1>

              <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-4">
                  <span className="inline-block bg-red-600/20 text-red-400 px-3 py-1 rounded">
                    {video.category}
                  </span>
                  <span className="text-slate-400">
                    {video.views.toLocaleString()} visualizaciones
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleToggleLike}
                    className="gap-2"
                  >
                    <ThumbsUp className="w-4 h-4" />
                    {reactions?.likes || 0}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleToggleDislike}
                    className="gap-2"
                  >
                    <ThumbsDown className="w-4 h-4" />
                    {reactions?.dislikes || 0}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleReport}
                  >
                    <Flag className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <p className="text-slate-300 text-lg">
                {video.description || "Sin descripción"}
              </p>
            </div>

            {/* Comments Section */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <MessageCircle className="w-6 h-6" />
                Comentarios
              </h2>

              {isAuthenticated && (
                <div className="bg-slate-800 rounded-lg p-4 space-y-4">
                  <Textarea
                    placeholder="Escribe un comentario..."
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 resize-none"
                    rows={3}
                  />
                  <Button
                    onClick={handleAddComment}
                    disabled={addCommentMutation.isPending}
                  >
                    {addCommentMutation.isPending ? "Publicando..." : "Comentar"}
                  </Button>
                </div>
              )}

              {commentsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-red-500" />
                </div>
              ) : comments && comments.length > 0 ? (
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div
                      key={comment.id}
                      className="bg-slate-800 rounded-lg p-4 space-y-2"
                    >
                      <p className="text-slate-300">{comment.content}</p>
                      <p className="text-xs text-slate-500">
                        Usuario #{comment.userId} •{" "}
                        {new Date(comment.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-400 text-center py-8">
                  No hay comentarios aún. ¡Sé el primero en comentar!
                </p>
              )}
            </div>
          </div>

          {/* Sidebar - Related Videos */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white">Videos Relacionados</h3>
            <div className="text-slate-400 text-center py-8">
              <p>Próximamente...</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
