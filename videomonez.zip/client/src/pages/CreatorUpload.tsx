import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Loader2, Play, Upload } from "lucide-react";
import { toast } from "sonner";

const CATEGORIES = [
  "Música",
  "Educación",
  "Entretenimiento",
  "Deportes",
  "Tecnología",
  "Viajes",
  "Comida",
  "Belleza",
  "Gaming",
  "Vlogs",
  "Otro",
];

export default function CreatorUpload() {
  const [, navigate] = useLocation();
  const { user } = useAuth();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [tags, setTags] = useState("");

  const createVideoMutation = trpc.video.create.useMutation();
  const publishVideoMutation = trpc.video.publish.useMutation();

  if (!user || (user.role !== "creator" && user.role !== "admin")) {
    navigate("/creator/setup");
    return null;
  }

  const handleUpload = async () => {
    if (!title.trim()) {
      toast.error("El título es requerido");
      return;
    }

    if (!category) {
      toast.error("Selecciona una categoría");
      return;
    }

    try {
      const videoResult = await createVideoMutation.mutateAsync({
        title,
        description,
        category,
        tags: tags ? tags.split(",").map((t) => t.trim()) : [],
      });

      // Publish the video
      if (videoResult && 'id' in videoResult) {
        await publishVideoMutation.mutateAsync({
          videoId: (videoResult.id as any) as number,
        });
      }

      toast.success("¡Video publicado exitosamente!");
      navigate("/creator/dashboard");
    } catch (error) {
      toast.error("Error al subir el video");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2 hover:opacity-80 transition">
            <Play className="w-6 h-6 text-red-500" />
            <span className="text-xl font-bold text-white">VideoMonez</span>
          </a>
          <div className="flex items-center gap-4">
            <a href="/feed" className="text-slate-300 hover:text-white transition">
              Feed
            </a>
            <a href="/creator/dashboard" className="text-slate-300 hover:text-white transition">
              Dashboard
            </a>
            <a href="/profile" className="text-slate-300 hover:text-white transition">
              Perfil
            </a>
          </div>
        </div>
      </div>

      <div className="container py-12">
        <div className="max-w-2xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold text-white">Subir Nuevo Video</h1>
            <p className="text-slate-400">
              Comparte tu contenido y comienza a ganar dinero
            </p>
          </div>

          <div className="bg-slate-800 rounded-lg p-8 space-y-6 border border-slate-700">
            {/* Title */}
            <div>
              <Label htmlFor="title" className="text-white mb-2 block">
                Título del Video *
              </Label>
              <Input
                id="title"
                placeholder="Ingresa el título de tu video"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
              />
              <p className="text-xs text-slate-400 mt-1">Máximo 255 caracteres</p>
            </div>

            {/* Description */}
            <div>
              <Label htmlFor="description" className="text-white mb-2 block">
                Descripción
              </Label>
              <Textarea
                id="description"
                placeholder="Describe tu video..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 resize-none"
                rows={4}
              />
            </div>

            {/* Category */}
            <div>
              <Label htmlFor="category" className="text-white mb-2 block">
                Categoría *
              </Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Selecciona una categoría" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  {CATEGORIES.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Tags */}
            <div>
              <Label htmlFor="tags" className="text-white mb-2 block">
                Etiquetas
              </Label>
              <Input
                id="tags"
                placeholder="Separa las etiquetas con comas (ej: música, tutorial, gaming)"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
              />
            </div>

            {/* Info Box */}
            <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-4 space-y-2">
              <p className="text-sm text-blue-300">
                <strong>Monetización automática:</strong> Tu video será monetizado automáticamente con anuncios pre-roll, mid-roll y post-roll.
              </p>
              <p className="text-sm text-blue-300">
                <strong>Formatos soportados:</strong> MP4, WebM, MOV (máximo 5GB)
              </p>
            </div>

            {/* Submit Button */}
            <Button
              onClick={handleUpload}
              disabled={createVideoMutation.isPending || publishVideoMutation.isPending}
              className="w-full bg-red-600 hover:bg-red-700"
              size="lg"
            >
              {createVideoMutation.isPending || publishVideoMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Publicando...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Publicar Video
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
