import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Play, Upload, Eye, DollarSign, TrendingUp } from "lucide-react";
import { toast } from "sonner";

export default function CreatorDashboard() {
  const { user } = useAuth();
  const [withdrawAmount, setWithdrawAmount] = useState("");

  const { data: stats, isLoading: statsLoading } = trpc.user.getCreatorStats.useQuery();
  const withdrawalMutation = trpc.withdrawal.request.useMutation();

  if (!user || (user.role !== "creator" && user.role !== "admin")) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-400 text-lg mb-4">Debes ser un creador para acceder aquí</p>
          <Link href="/creator/setup">
            <a>
              <Button>Convertirse en Creador</Button>
            </a>
          </Link>
        </div>
      </div>
    );
  }

  const handleWithdraw = async () => {
    if (!withdrawAmount || parseFloat(withdrawAmount) < 5) {
      toast.error("El monto mínimo de retiro es $5");
      return;
    }

    try {
      await withdrawalMutation.mutateAsync({
        amount: parseFloat(withdrawAmount),
      });
      setWithdrawAmount("");
      toast.success("Solicitud de retiro enviada");
    } catch (error) {
      toast.error("Error al solicitar retiro");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition">
              <Play className="w-6 h-6 text-red-500" />
              <span className="text-xl font-bold text-white">VideoMonez</span>
            </a>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/feed">
              <a className="text-slate-300 hover:text-white transition">Feed</a>
            </Link>
            <Link href="/creator/upload">
              <a className="text-slate-300 hover:text-white transition">Subir Video</a>
            </Link>
            <Link href="/profile">
              <a className="text-slate-300 hover:text-white transition">Perfil</a>
            </Link>
          </div>
        </div>
      </div>

      <div className="container py-8">
        {statsLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-red-500" />
          </div>
        ) : stats ? (
          <div className="space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Total Views */}
              <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Visualizaciones Totales</p>
                    <p className="text-3xl font-bold text-white mt-2">
                      {stats.totalViews.toLocaleString()}
                    </p>
                  </div>
                  <Eye className="w-8 h-8 text-blue-500 opacity-50" />
                </div>
              </div>

              {/* Published Videos */}
              <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Videos Publicados</p>
                    <p className="text-3xl font-bold text-white mt-2">
                      {stats.publishedVideos}
                    </p>
                  </div>
                  <Play className="w-8 h-8 text-purple-500 opacity-50" />
                </div>
              </div>

              {/* Total Earnings */}
              <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Ganancias Totales</p>
                    <p className="text-3xl font-bold text-white mt-2">
                      ${parseFloat(stats.totalEarnings.toString()).toFixed(2)}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-500 opacity-50" />
                </div>
              </div>

              {/* Pending Earnings */}
              <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Ganancias Pendientes</p>
                    <p className="text-3xl font-bold text-white mt-2">
                      ${parseFloat(stats.pendingEarnings.toString()).toFixed(2)}
                    </p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-yellow-500 opacity-50" />
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Upload Video */}
              <Link href="/creator/upload">
                <a>
                  <div className="bg-slate-800 rounded-lg p-6 border border-slate-700 hover:border-red-500 transition cursor-pointer">
                    <Upload className="w-8 h-8 text-red-500 mb-4" />
                    <h3 className="text-lg font-semibold text-white">Subir Nuevo Video</h3>
                    <p className="text-slate-400 text-sm mt-2">
                      Crea y publica tu próximo video
                    </p>
                  </div>
                </a>
              </Link>

              {/* Request Withdrawal */}
              <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
                <DollarSign className="w-8 h-8 text-green-500 mb-4" />
                <h3 className="text-lg font-semibold text-white">Solicitar Retiro</h3>
                <div className="mt-4 space-y-3">
                  <Input
                    type="number"
                    placeholder="Monto ($5 mínimo)"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                    min="5"
                    step="0.01"
                  />
                  <Button
                    onClick={handleWithdraw}
                    disabled={withdrawalMutation.isPending}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    {withdrawalMutation.isPending ? "Procesando..." : "Solicitar Retiro"}
                  </Button>
                </div>
              </div>
            </div>

            {/* Videos Section */}
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-white">Mis Videos</h2>
              {stats.videos && stats.videos.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {stats.videos.map((video) => (
                    <Link key={video.id} href={`/video/${video.id}`}>
                      <a className="group">
                        <div className="bg-slate-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-red-500 transition">
                          <div className="bg-slate-700 aspect-video flex items-center justify-center group-hover:bg-slate-600 transition">
                            <Play className="w-12 h-12 text-slate-500" />
                          </div>
                          <div className="p-4 space-y-2">
                            <h3 className="font-semibold text-white line-clamp-2">
                              {video.title}
                            </h3>
                            <div className="flex items-center justify-between text-sm text-slate-400">
                              <span>{video.views} vistas</span>
                              <span className={`px-2 py-1 rounded text-xs ${
                                video.status === "published"
                                  ? "bg-green-600/20 text-green-400"
                                  : "bg-yellow-600/20 text-yellow-400"
                              }`}>
                                {video.status === "published" ? "Publicado" : "Borrador"}
                              </span>
                            </div>
                          </div>
                        </div>
                      </a>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="bg-slate-800 rounded-lg p-12 text-center border border-slate-700">
                  <p className="text-slate-400 mb-4">No tienes videos aún</p>
                  <Link href="/creator/upload">
                    <a>
                      <Button>Subir tu primer video</Button>
                    </a>
                  </Link>
                </div>
              )}
            </div>

            {/* Withdrawal History */}
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-white">Historial de Retiros</h2>
              {stats.withdrawals && stats.withdrawals.length > 0 ? (
                <div className="space-y-3">
                  {stats.withdrawals.map((withdrawal) => (
                    <div
                      key={withdrawal.id}
                      className="bg-slate-800 rounded-lg p-4 border border-slate-700 flex items-center justify-between"
                    >
                      <div>
                        <p className="text-white font-semibold">
                          ${withdrawal.amount}
                        </p>
                        <p className="text-sm text-slate-400">
                          {new Date(withdrawal.requestedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <span className={`px-3 py-1 rounded text-sm ${
                        withdrawal.status === "completed"
                          ? "bg-green-600/20 text-green-400"
                          : withdrawal.status === "pending"
                          ? "bg-yellow-600/20 text-yellow-400"
                          : "bg-red-600/20 text-red-400"
                      }`}>
                        {withdrawal.status === "completed"
                          ? "Completado"
                          : withdrawal.status === "pending"
                          ? "Pendiente"
                          : "Rechazado"}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-400 text-center py-8">
                  No tienes retiros aún
                </p>
              )}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
