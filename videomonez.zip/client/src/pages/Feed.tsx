import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Link } from "wouter";
import { Play, Eye, ThumbsUp, ThumbsDown } from "lucide-react";
import { Loader2 } from "lucide-react";

const CATEGORIES = [
  "Música",
  "Educación",
  "Entretenimiento",
  "Deportes",
  "Tecnología",
  "Viajes",
  "Comida",
  "Belleza",
  "Gaming",
  "Vlogs",
  "Otro",
];

export default function Feed() {
  const [page, setPage] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();
  const [searchTerm, setSearchTerm] = useState("");

  const limit = 10;
  const offset = page * limit;

  const { data: videos, isLoading } = trpc.video.getFeed.useQuery({
    limit,
    offset,
    category: selectedCategory,
  });

  const filteredVideos = videos?.filter((v) =>
    v.title.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur sticky top-0 z-10">
        <div className="container py-4 space-y-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <a className="flex items-center gap-2 hover:opacity-80 transition">
                <Play className="w-6 h-6 text-red-500" />
                <span className="text-xl font-bold text-white">VideoMonez</span>
              </a>
            </Link>
            <div className="flex items-center gap-4">
              <Link href="/feed">
                <a className="text-slate-300 hover:text-white transition">Feed</a>
              </Link>
              <Link href="/creator/dashboard">
                <a className="text-slate-300 hover:text-white transition">Dashboard</a>
              </Link>
              <Link href="/profile">
                <a className="text-slate-300 hover:text-white transition">Perfil</a>
              </Link>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              placeholder="Buscar videos..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setPage(0);
              }}
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-400"
            />
            <Select value={selectedCategory || ""} onValueChange={(v) => {
              setSelectedCategory(v || undefined);
              setPage(0);
            }}>
              <SelectTrigger className="w-full sm:w-48 bg-slate-800 border-slate-700 text-white">
                <SelectValue placeholder="Categoría" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="">Todas las categorías</SelectItem>
                {CATEGORIES.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Videos Grid */}
      <div className="container py-8">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-red-500" />
          </div>
        ) : filteredVideos.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-slate-400 text-lg">No hay videos disponibles</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredVideos.map((video) => (
                <Link key={video.id} href={`/video/${video.id}`}>
                  <a className="group cursor-pointer">
                    <div className="bg-slate-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-red-500 transition">
                      {/* Thumbnail */}
                      <div className="relative bg-slate-700 aspect-video flex items-center justify-center group-hover:bg-slate-600 transition">
                        {video.thumbnailUrl ? (
                          <img
                            src={video.thumbnailUrl}
                            alt={video.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Play className="w-12 h-12 text-slate-500" />
                        )}
                        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition flex items-center justify-center opacity-0 group-hover:opacity-100">
                          <Play className="w-12 h-12 text-white" />
                        </div>
                      </div>

                      {/* Info */}
                      <div className="p-3 space-y-2">
                        <h3 className="font-semibold text-white line-clamp-2 group-hover:text-red-400 transition">
                          {video.title}
                        </h3>
                        <p className="text-sm text-slate-400 line-clamp-2">
                          {video.description || "Sin descripción"}
                        </p>

                        {/* Stats */}
                        <div className="flex items-center gap-4 text-xs text-slate-400 pt-2">
                          <div className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            <span>{video.views.toLocaleString()}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <ThumbsUp className="w-4 h-4" />
                            <span>{video.likes.toLocaleString()}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <ThumbsDown className="w-4 h-4" />
                            <span>{video.dislikes.toLocaleString()}</span>
                          </div>
                        </div>

                        {/* Category */}
                        <div className="pt-2">
                          <span className="inline-block bg-red-600/20 text-red-400 text-xs px-2 py-1 rounded">
                            {video.category}
                          </span>
                        </div>
                      </div>
                    </div>
                  </a>
                </Link>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-center gap-4 mt-12">
              <Button
                variant="outline"
                disabled={page === 0}
                onClick={() => setPage(page - 1)}
              >
                Anterior
              </Button>
              <span className="text-slate-400">Página {page + 1}</span>
              <Button
                variant="outline"
                disabled={filteredVideos.length < limit}
                onClick={() => setPage(page + 1)}
              >
                Siguiente
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
