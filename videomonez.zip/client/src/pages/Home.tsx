import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { Play, Users, TrendingUp, DollarSign } from "lucide-react";
import AppHeader from "@/components/AppHeader";

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <AppHeader />

      {/* Hero Section */}
      <section className="flex-1 flex flex-col items-center justify-center px-4 py-20">
        <div className="max-w-3xl text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold text-white">
              Monetiza tu contenido de video
            </h1>
            <p className="text-xl text-slate-300">
              Sube tus videos, gana dinero automáticamente con anuncios inteligentes y retira tus ganancias cuando quieras.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {isAuthenticated ? (
              <>
                <Link href="/feed">
                  <a>
                    <Button size="lg" className="bg-red-600 hover:bg-red-700">
                      Explorar Videos
                    </Button>
                  </a>
                </Link>
                <Link href="/creator/dashboard">
                  <a>
                    <Button size="lg" variant="outline">
                      Mi Dashboard
                    </Button>
                  </a>
                </Link>
              </>
            ) : (
              <>
                <a href={getLoginUrl()}>
                  <Button size="lg" className="bg-red-600 hover:bg-red-700">
                    Comenzar Ahora
                  </Button>
                </a>
                <Button size="lg" variant="outline">
                  Más Información
                </Button>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-slate-800/50 py-20 px-4">
        <div className="container">
          <h2 className="text-3xl font-bold text-white text-center mb-16">
            ¿Por qué elegir VideoMonez?
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Feature 1 */}
            <div className="bg-slate-700/50 rounded-lg p-6 border border-slate-600 hover:border-red-500 transition">
              <Play className="w-8 h-8 text-red-500 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Sube Fácilmente</h3>
              <p className="text-slate-300">
                Sube videos en MP4, WebM o MOV hasta 5GB sin complicaciones
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-slate-700/50 rounded-lg p-6 border border-slate-600 hover:border-red-500 transition">
              <DollarSign className="w-8 h-8 text-green-500 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Gana Dinero</h3>
              <p className="text-slate-300">
                Monetización automática con anuncios pre-roll, mid-roll y post-roll
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-slate-700/50 rounded-lg p-6 border border-slate-600 hover:border-red-500 transition">
              <TrendingUp className="w-8 h-8 text-blue-500 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Estadísticas</h3>
              <p className="text-slate-300">
                Dashboard en tiempo real con métricas detalladas de tus videos
              </p>
            </div>

            {/* Feature 4 */}
            <div className="bg-slate-700/50 rounded-lg p-6 border border-slate-600 hover:border-red-500 transition">
              <Users className="w-8 h-8 text-purple-500 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Comunidad</h3>
              <p className="text-slate-300">
                Conecta con otros creadores y comparte tu contenido
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-4">
        <div className="container">
          <h2 className="text-3xl font-bold text-white text-center mb-16">
            Tasas de Monetización
          </h2>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-slate-700/50 rounded-lg p-6 border border-slate-600">
              <h3 className="text-lg font-semibold text-white mb-4">Pre-Roll</h3>
              <div className="space-y-2 text-slate-300">
                <p>CPM: $2.00 - $5.00</p>
                <p>CPC: $0.50 - $1.00</p>
                <p className="text-sm text-slate-400">Anuncios antes del video</p>
              </div>
            </div>

            <div className="bg-slate-700/50 rounded-lg p-6 border border-slate-600">
              <h3 className="text-lg font-semibold text-white mb-4">Mid-Roll</h3>
              <div className="space-y-2 text-slate-300">
                <p>CPM: $1.50 - $3.50</p>
                <p>CPC: $0.30 - $0.75</p>
                <p className="text-sm text-slate-400">Anuncios durante el video</p>
              </div>
            </div>

            <div className="bg-slate-700/50 rounded-lg p-6 border border-slate-600">
              <h3 className="text-lg font-semibold text-white mb-4">Post-Roll</h3>
              <div className="space-y-2 text-slate-300">
                <p>CPM: $1.00 - $2.50</p>
                <p>CPC: $0.25 - $0.50</p>
                <p className="text-sm text-slate-400">Anuncios después del video</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-red-600 to-red-700 py-16 px-4">
        <div className="container text-center space-y-6">
          <h2 className="text-3xl font-bold text-white">
            ¿Listo para comenzar?
          </h2>
          <p className="text-lg text-red-100 max-w-2xl mx-auto">
            Únete a miles de creadores que ya están ganando dinero con sus videos
          </p>
          {!isAuthenticated && (
            <a href={getLoginUrl()}>
              <Button
                size="lg"
                className="bg-white text-red-600 hover:bg-slate-100"
              >
                Registrarse Ahora
              </Button>
            </a>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900 py-8 px-4">
        <div className="container text-center text-slate-400">
          <p>&copy; 2026 VideoMonez. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
