ALTER TABLE `ads` MODIFY COLUMN `cpmRate` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `ads` MODIFY COLUMN `cpcRate` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `earnings` MODIFY COLUMN `amount` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `withdrawals` MODIFY COLUMN `amount` varchar(20) NOT NULL;