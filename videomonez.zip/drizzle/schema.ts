import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  longtext,
  datetime,
} from "drizzle-orm/mysql-core";

/**
 * Extended users table with creator fields
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "creator", "admin"]).default("user").notNull(),
  paypalEmail: varchar("paypalEmail", { length: 320 }),
  bio: text("bio"),
  avatarUrl: text("avatarUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Videos table
 */
export const videos = mysqlTable("videos", {
  id: int("id").autoincrement().primaryKey(),
  creatorId: int("creatorId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: longtext("description"),
  category: varchar("category", { length: 50 }).notNull(),
  tags: text("tags"), // JSON array stored as string
  videoUrl: text("videoUrl"),
  thumbnailUrl: text("thumbnailUrl"),
  duration: int("duration"), // in seconds
  status: mysqlEnum("status", ["draft", "published", "deleted"]).default("draft").notNull(),
  views: int("views").default(0).notNull(),
  likes: int("likes").default(0).notNull(),
  dislikes: int("dislikes").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  publishedAt: timestamp("publishedAt"),
});

export type Video = typeof videos.$inferSelect;
export type InsertVideo = typeof videos.$inferInsert;

/**
 * Ads table
 */
export const ads = mysqlTable("ads", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  type: mysqlEnum("type", ["pre-roll", "mid-roll", "post-roll"]).notNull(),
  positionSeconds: int("positionSeconds"), // for mid-roll
  cpmRate: varchar("cpmRate", { length: 20 }).notNull(), // e.g., 2.50
  cpcRate: varchar("cpcRate", { length: 20 }).notNull(), // e.g., 0.75
  impressions: int("impressions").default(0).notNull(),
  clicks: int("clicks").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Ad = typeof ads.$inferSelect;
export type InsertAd = typeof ads.$inferInsert;

/**
 * Earnings table
 */
export const earnings = mysqlTable("earnings", {
  id: int("id").autoincrement().primaryKey(),
  creatorId: int("creatorId").notNull(),
  videoId: int("videoId").notNull(),
  adId: int("adId"),
  amount: varchar("amount", { length: 20 }).notNull(),
  type: mysqlEnum("type", ["view", "click"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Earning = typeof earnings.$inferSelect;
export type InsertEarning = typeof earnings.$inferInsert;

/**
 * Withdrawals table
 */
export const withdrawals = mysqlTable("withdrawals", {
  id: int("id").autoincrement().primaryKey(),
  creatorId: int("creatorId").notNull(),
  amount: varchar("amount", { length: 20 }).notNull(),
  status: mysqlEnum("status", ["pending", "completed", "rejected"]).default("pending").notNull(),
  paypalEmail: varchar("paypalEmail", { length: 320 }).notNull(),
  transactionId: varchar("transactionId", { length: 255 }),
  reason: text("reason"), // reason for rejection
  requestedAt: timestamp("requestedAt").defaultNow().notNull(),
  processedAt: timestamp("processedAt"),
  reviewedBy: int("reviewedBy"), // admin user id
});

export type Withdrawal = typeof withdrawals.$inferSelect;
export type InsertWithdrawal = typeof withdrawals.$inferInsert;

/**
 * Comments table
 */
export const comments = mysqlTable("comments", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  userId: int("userId").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Comment = typeof comments.$inferSelect;
export type InsertComment = typeof comments.$inferInsert;

/**
 * Reactions table (likes/dislikes)
 */
export const reactions = mysqlTable("reactions", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["like", "dislike"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Reaction = typeof reactions.$inferSelect;
export type InsertReaction = typeof reactions.$inferInsert;

/**
 * Video analytics table
 */
export const videoAnalytics = mysqlTable("videoAnalytics", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  userId: int("userId"),
  watchDuration: int("watchDuration").default(0).notNull(), // in seconds
  completed: boolean("completed").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VideoAnalytic = typeof videoAnalytics.$inferSelect;
export type InsertVideoAnalytic = typeof videoAnalytics.$inferInsert;

/**
 * Ad impressions table
 */
export const adImpressions = mysqlTable("adImpressions", {
  id: int("id").autoincrement().primaryKey(),
  adId: int("adId").notNull(),
  videoId: int("videoId").notNull(),
  userId: int("userId"),
  clicked: boolean("clicked").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AdImpression = typeof adImpressions.$inferSelect;
export type InsertAdImpression = typeof adImpressions.$inferInsert;

/**
 * Content flags (reports) table
 */
export const contentFlags = mysqlTable("contentFlags", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId"),
  commentId: int("commentId"),
  reportedBy: int("reportedBy").notNull(),
  reason: mysqlEnum("reason", [
    "spam",
    "inappropriate",
    "copyright",
    "harassment",
    "other",
  ]).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["pending", "reviewed", "resolved"]).default("pending").notNull(),
  reviewedBy: int("reviewedBy"),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContentFlag = typeof contentFlags.$inferSelect;
export type InsertContentFlag = typeof contentFlags.$inferInsert;

/**
 * Notifications table
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: varchar("type", { length: 50 }).notNull(), // e.g., "new_comment", "withdrawal_approved"
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;
